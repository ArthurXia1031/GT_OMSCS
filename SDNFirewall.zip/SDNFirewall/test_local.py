import sys
sys.path.append('.') # Assuming mock pox modules can be faked
from setup_mock import process_configuration

policies = process_configuration('configure.pol')
print("Successfully loaded policies:", len(policies))

import sdn_firewall
try:
    rules = sdn_firewall.firewall_policy_processing(policies)
    print("Generated rules:", len(rules))
except Exception as e:
    print("Exception generating rules:", e)
