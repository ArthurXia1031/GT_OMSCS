class IPAddr:
    def __init__(self, val): self.val = val
class EthAddr:
    def __init__(self, val): self.val = val
class MockMatch:
    pass
class MockFlowMod:
    def __init__(self):
        self.match = MockMatch()
        self.actions = []
class MockOF:
    OFPP_NORMAL = 0
    def ofp_flow_mod(self): return MockFlowMod()
    def ofp_match(self): return MockMatch()
    def ofp_action_output(self, port): return port
of = MockOF()

def firewall_policy_processing(policies):
    rules = []
    for policy in policies:
        rule = of.ofp_flow_mod()
        rule.match = of.ofp_match()
        rule.match.dl_type = 0x0800

        is_allow = (policy['action'] == 'Allow')
        base_priority = 50000 if is_allow else 40000
        try:
            rnum = int(policy['rulenum'])
        except ValueError:
            rnum = 0
        rule.priority = base_priority + rnum

        if policy['mac-src'] != '-':
            rule.match.dl_src = EthAddr(policy['mac-src'])
        if policy['mac-dst'] != '-':
            rule.match.dl_dst = EthAddr(policy['mac-dst'])

        if policy['ipprotocol'] != '-':
            rule.match.nw_proto = int(policy['ipprotocol'])

        if policy['ip-src'] != '-':
            rule.match.nw_src = (policy['ip-src-address'], int(policy['ip-src-subnet']))
        if policy['ip-dst'] != '-':
            rule.match.nw_dst = (policy['ip-dst-address'], int(policy['ip-dst-subnet']))

        if policy['port-src'] != '-':
            rule.match.tp_src = int(policy['port-src'])
        if policy['port-dst'] != '-':
            rule.match.tp_dst = int(policy['port-dst'])

        if is_allow:
            rule.actions.append(of.ofp_action_output(port=of.OFPP_NORMAL))
        rules.append(rule)
    return rules

import csv
fields = ('rulenum','action','mac-src','mac-dst','ip-src','ip-dst','ipprotocol','port-src','port-dst','comment')
policies = []
with open('configure.pol','r') as f:
    reader = csv.DictReader(filter(lambda row: row[0]!='#', f), fieldnames=fields)
    for r in reader:
        if r['ip-src'] != '-':
            arr = r['ip-src'].split('/')
            r['ip-src-address'] = arr[0]
            r['ip-src-subnet'] = arr[1]
        if r['ip-dst'] != '-':
            arr = r['ip-dst'].split('/')
            r['ip-dst-address'] = arr[0]
            r['ip-dst-subnet'] = arr[1]
        policies.append(r)

res = firewall_policy_processing(policies)
print("SUCCESS!", len(res))
